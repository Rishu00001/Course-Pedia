import express from "express";
import dotenv from "dotenv";
import connectDb from "./config/connectDb.js";
import cookieParser from "cookie-parser";
import authRouter from "./route/authRouter.js";
import cors from "cors";
import userRouter from "./route/userRouter.js";
import courseRouter from "./route/courseRouter.js";
import paymentRouter from "./route/paymentroutes.js";
import reviewRouter from "./route/reviewRouter.js";
dotenv.config();
const PORT = process.env.PORT || 8000;
const app = express();
app.use(
  cors({
    origin: process.env.CLIENT_URL,
    credentials: true,
  })
);
app.use(express.json());
app.use(cookieParser());

app.use("/api/auth", authRouter);
app.use("/api/user", userRouter);
app.use("/api/review", reviewRouter);
app.use("/api/course", courseRouter);
app.use("/api/order", paymentRouter);
app.get("/", (req, res) => {
  res.send("Hello from server");
});

await connectDb(); //connect to the database first
app.listen(PORT, () => {
  console.log(`App listening at port ${PORT}`);
});
